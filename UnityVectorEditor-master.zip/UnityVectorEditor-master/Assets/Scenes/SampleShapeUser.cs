﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SampleShapeUser : MonoBehaviour
{
	public SerializedShape shape;

    void Update()
    {
        
    }
}
